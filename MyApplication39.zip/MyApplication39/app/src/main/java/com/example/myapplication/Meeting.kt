package com.example.myapplication

data class Meeting(
    val id: String,
    val title: String,
    val description: String,
    val date: String,
    val status: String
)
